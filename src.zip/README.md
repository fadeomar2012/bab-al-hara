# Bab Al Hara E-commerce

Mobile-first **Arabic RTL** fashion & lifestyle e-commerce app for **Bab Al Hara**, built on a real PostgreSQL + Prisma backend. The storefront keeps a warm boutique identity (cream, beige, camel, tan, brown, black with soft gold accents) while behaving like a fast mobile marketplace.

This is a working **Sprint 5** codebase: real database-backed orders, a protected admin dashboard, full order/inventory/invoice/packing-slip workflow, and CSV export.

## Stack

- Next.js (App Router)
- TypeScript
- Prisma ORM
- PostgreSQL
- Arabic RTL, mobile-first CSS
- LocalStorage cart
- Cookie-based admin dashboard auth

## Features

### Storefront
- Homepage with hero, category showcase, offers, new arrivals, best sellers
- Category listing pages (real categories + virtual `new-in` / `sale`)
- Product detail pages with variants (color, size, SKU, price, stock)
- LocalStorage cart with product/variant snapshots
- Cash on Delivery (COD) checkout that creates **real database orders**
- Order success confirmation
- Public order tracking by order number

### Admin
- Protected login (cookie session)
- Dashboard overview
- Product management (create / edit / list)
- Category management
- Banner management
- Inventory management with manual stock adjustments
- Order management with status transitions, notes, and a "packed" toggle
- Printable invoice
- Printable packing slip
- CSV export of orders

### Backend / business logic
- Database-backed orders with server-side price calculation
- Customer upsert on checkout
- Transactional stock deduction (locked stock transaction)
- Inventory logs for every stock change
- Stock restore on order cancellation
- Order status history

## Routes

### Storefront
| Route | Description |
| --- | --- |
| `/` | Homepage |
| `/category/[slug]` | Category / collection listing (incl. virtual `new-in`, `sale`) with search, sort, availability filters |
| `/product/[slug]` | Product detail with variant selection and add-to-cart |
| `/cart` | LocalStorage cart review |
| `/checkout` | COD checkout form; creates a real order |
| `/order-success` | Order confirmation (reads `?order=` number) |
| `/track-order` | Public order tracking by order number |

### Admin (protected)
| Route | Description |
| --- | --- |
| `/admin/login` | Staff login |
| `/admin` | Dashboard overview |
| `/admin/products` | Product list |
| `/admin/products/new` | Create product |
| `/admin/products/[id]/edit` | Edit product |
| `/admin/categories` | Category management |
| `/admin/banners` | Banner management |
| `/admin/inventory` | Inventory + manual stock adjustments |
| `/admin/orders` | Order list with filters |
| `/admin/orders/[id]` | Order detail: status transitions, notes, packed toggle |
| `/admin/orders/[id]/invoice` | Printable invoice |
| `/admin/orders/[id]/packing-slip` | Printable packing slip |
| `/admin/orders/export` | CSV export endpoint |

## Setup

```bash
npm install
npm run db:generate   # prisma generate
npm run db:push       # sync schema to the database
npm run db:seed       # seed categories, products, banners
npm run typecheck
npm run lint
npm run build
npm run dev
```

For a migration-file workflow instead of `db:push`:

```bash
npm run db:migrate
```

## Environment variables

Copy `.env.example` to `.env` and fill in your local values. **Never commit real secrets** — `.env`, `.env.local`, and `.env.*.local` are gitignored.

| Variable | Purpose |
| --- | --- |
| `DATABASE_URL` | PostgreSQL connection string used by Prisma |
| `ADMIN_EMAIL` | Admin login email (used by the seed script) |
| `ADMIN_PASSWORD` | Admin login password (used by the seed script) |
| `ADMIN_NAME` | Display name for the seeded admin |
| `ADMIN_SESSION_SECRET` | Secret used to sign the admin session cookie |
| `NEXT_PUBLIC_SITE_URL` | Public base URL used for QR codes on invoices / packing slips and order-tracking links |

`.env.example` contains placeholder values only and is safe to commit.

## Project structure

- `src/app/(storefront)` — public storefront routes and layout
- `src/app/admin` — admin login and protected admin routes
- `src/components` — storefront UI components (`src/components/admin` for admin UI)
- `src/features/catalog` — catalog queries, mappers, filters, types
- `src/features/orders` — order pricing, stock, validation, actions
- `src/features/admin/*` — admin queries, actions, and validation per domain
- `prisma/` — Prisma schema and seed script

## QA status

Sprint 5 QA-polished build. Checkout, orders, inventory, invoices, packing slips, and CSV export are real and functional. Customer accounts and a wishlist are intentionally **not** part of this sprint.
