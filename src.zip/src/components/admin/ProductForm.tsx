'use client';

import { useMemo, useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { createProductAction, updateProductAction, type ActionIssue } from '@/features/admin/products/product-admin.actions';
import type { ProductInput } from '@/features/admin/products/product-admin.validation';
import { slugify } from '@/features/admin/shared/admin-format';

type CategoryOption = { id: string; name: string; isActive: boolean };

type ImageState = { id?: string; url: string; alt: string; isPrimary: boolean };
type VariantState = {
  id?: string;
  sku: string;
  colorName: string;
  colorValue: string;
  size: string;
  price: string;
  compareAtPrice: string;
  quantity: string;
  lowStockThreshold: string;
  isActive: boolean;
};

export type ProductFormInitial = {
  id?: string;
  name: string;
  slug: string;
  subtitle: string;
  description: string;
  details: string[];
  careInstructions: string;
  brand: string;
  categoryId: string;
  basePrice: number | '';
  compareAtPrice?: number;
  status: 'DRAFT' | 'ACTIVE' | 'ARCHIVED';
  isFeatured: boolean;
  isNewArrival: boolean;
  isBestSeller: boolean;
  tags: string[];
  images: ImageState[];
  variants: VariantState[];
};

const EMPTY_VARIANT: VariantState = {
  sku: '',
  colorName: '',
  colorValue: '',
  size: '',
  price: '',
  compareAtPrice: '',
  quantity: '0',
  lowStockThreshold: '5',
  isActive: true
};

export function buildEmptyProduct(): ProductFormInitial {
  return {
    name: '',
    slug: '',
    subtitle: '',
    description: '',
    details: [],
    careInstructions: '',
    brand: '',
    categoryId: '',
    basePrice: '',
    status: 'DRAFT',
    isFeatured: false,
    isNewArrival: false,
    isBestSeller: false,
    tags: [],
    images: [],
    variants: [{ ...EMPTY_VARIANT }]
  };
}

function numberOrUndefined(value: string): number | undefined {
  const trimmed = value.trim();
  if (trimmed === '') return undefined;
  const num = Number(trimmed);
  return Number.isFinite(num) ? num : undefined;
}

export function ProductForm({
  mode,
  productId,
  categories,
  initial
}: {
  mode: 'create' | 'edit';
  productId?: string;
  categories: CategoryOption[];
  initial: ProductFormInitial;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();

  const [name, setName] = useState(initial.name);
  const [slug, setSlug] = useState(initial.slug);
  const [slugEdited, setSlugEdited] = useState(mode === 'edit');
  const [subtitle, setSubtitle] = useState(initial.subtitle);
  const [description, setDescription] = useState(initial.description);
  const [details, setDetails] = useState(initial.details.join('\n'));
  const [careInstructions, setCareInstructions] = useState(initial.careInstructions);
  const [brand, setBrand] = useState(initial.brand);
  const [categoryId, setCategoryId] = useState(initial.categoryId);
  const [basePrice, setBasePrice] = useState(initial.basePrice === '' ? '' : String(initial.basePrice));
  const [compareAtPrice, setCompareAtPrice] = useState(initial.compareAtPrice != null ? String(initial.compareAtPrice) : '');
  const [status, setStatus] = useState(initial.status);
  const [isFeatured, setIsFeatured] = useState(initial.isFeatured);
  const [isNewArrival, setIsNewArrival] = useState(initial.isNewArrival);
  const [isBestSeller, setIsBestSeller] = useState(initial.isBestSeller);
  const [tags, setTags] = useState(initial.tags.join(', '));
  const [images, setImages] = useState<ImageState[]>(initial.images);
  const [variants, setVariants] = useState<VariantState[]>(initial.variants.length ? initial.variants : [{ ...EMPTY_VARIANT }]);

  const [formMessage, setFormMessage] = useState<string | null>(null);
  const [issues, setIssues] = useState<Record<string, string>>({});

  const errorFor = (path: string) => issues[path];

  const activeVariantCount = useMemo(() => variants.filter((variant) => variant.isActive).length, [variants]);

  function onNameChange(value: string) {
    setName(value);
    if (!slugEdited) setSlug(slugify(value));
  }

  function setPrimaryImage(index: number) {
    setImages((prev) => prev.map((image, i) => ({ ...image, isPrimary: i === index })));
  }

  function updateImage(index: number, patch: Partial<ImageState>) {
    setImages((prev) => prev.map((image, i) => (i === index ? { ...image, ...patch } : image)));
  }

  function updateVariant(index: number, patch: Partial<VariantState>) {
    setVariants((prev) => prev.map((variant, i) => (i === index ? { ...variant, ...patch } : variant)));
  }

  function buildPayload(): ProductInput {
    return {
      name: name.trim(),
      slug: slug.trim(),
      subtitle: subtitle.trim() || undefined,
      description: description.trim(),
      details: details.split('\n').map((line) => line.trim()).filter(Boolean),
      careInstructions: careInstructions.trim() || undefined,
      brand: brand.trim() || undefined,
      categoryId,
      basePrice: numberOrUndefined(basePrice) ?? Number.NaN,
      compareAtPrice: numberOrUndefined(compareAtPrice),
      status,
      isFeatured,
      isNewArrival,
      isBestSeller,
      tags: tags.split(',').map((tag) => tag.trim()).filter(Boolean),
      images: images.map((image, index) => ({
        id: image.id,
        url: image.url.trim(),
        alt: image.alt.trim() || undefined,
        sortOrder: index,
        isPrimary: image.isPrimary
      })),
      variants: variants.map((variant) => ({
        id: variant.id,
        sku: variant.sku.trim(),
        colorName: variant.colorName.trim() || undefined,
        colorValue: variant.colorValue.trim() || undefined,
        size: variant.size.trim() || undefined,
        price: numberOrUndefined(variant.price) ?? Number.NaN,
        compareAtPrice: numberOrUndefined(variant.compareAtPrice),
        quantity: numberOrUndefined(variant.quantity) ?? 0,
        lowStockThreshold: numberOrUndefined(variant.lowStockThreshold) ?? 0,
        isActive: variant.isActive
      }))
    };
  }

  function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setFormMessage(null);
    setIssues({});

    const payload = buildPayload();
    startTransition(async () => {
      const result = mode === 'create'
        ? await createProductAction(payload)
        : await updateProductAction(productId as string, payload);

      // On success the action redirects; we only get here on failure.
      if (result && !result.ok) {
        setFormMessage(result.message);
        const map: Record<string, string> = {};
        result.issues.forEach((issue: ActionIssue) => {
          map[issue.path] = issue.message;
        });
        setIssues(map);
        if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });
  }

  return (
    <form className="adminForm" onSubmit={handleSubmit}>
      {formMessage && <div className="adminAlert isError" role="alert">{formMessage}</div>}
      {status === 'ACTIVE' && activeVariantCount === 0 && (
        <div className="adminAlert isInfo">An ACTIVE product needs at least one active variant before it can be saved.</div>
      )}

      {/* Basics */}
      <div className="adminCard">
        <div className="adminCardHeader"><h2>Product basics</h2></div>
        <div className="adminFormGrid two">
          <div className="adminField">
            <label htmlFor="p-name">Name *</label>
            <input id="p-name" className={errorFor('name') ? 'hasError' : ''} value={name} onChange={(e) => onNameChange(e.target.value)} required />
            {errorFor('name') && <span className="adminFieldError">{errorFor('name')}</span>}
          </div>
          <div className="adminField">
            <label htmlFor="p-slug">Slug *</label>
            <input
              id="p-slug"
              className={errorFor('slug') ? 'hasError' : ''}
              value={slug}
              onChange={(e) => { setSlug(e.target.value); setSlugEdited(true); }}
              onBlur={(e) => setSlug(slugify(e.target.value))}
              required
            />
            {errorFor('slug') ? <span className="adminFieldError">{errorFor('slug')}</span> : <span className="adminFieldHint">Used in the storefront URL. Auto-filled from the name.</span>}
          </div>
          <div className="adminField spanTwo">
            <label htmlFor="p-subtitle">Subtitle</label>
            <input id="p-subtitle" value={subtitle} onChange={(e) => setSubtitle(e.target.value)} />
          </div>
          <div className="adminField spanTwo">
            <label htmlFor="p-description">Description *</label>
            <textarea id="p-description" className={errorFor('description') ? 'hasError' : ''} value={description} onChange={(e) => setDescription(e.target.value)} required />
            {errorFor('description') && <span className="adminFieldError">{errorFor('description')}</span>}
          </div>
          <div className="adminField">
            <label htmlFor="p-details">Details (one per line)</label>
            <textarea id="p-details" value={details} onChange={(e) => setDetails(e.target.value)} placeholder={'Soft material\nGift ready'} />
          </div>
          <div className="adminField">
            <label htmlFor="p-care">Care instructions</label>
            <textarea id="p-care" value={careInstructions} onChange={(e) => setCareInstructions(e.target.value)} />
          </div>
          <div className="adminField">
            <label htmlFor="p-brand">Brand</label>
            <input id="p-brand" value={brand} onChange={(e) => setBrand(e.target.value)} />
          </div>
          <div className="adminField">
            <label htmlFor="p-tags">Tags (comma separated)</label>
            <input id="p-tags" value={tags} onChange={(e) => setTags(e.target.value)} placeholder="gift, summer" />
          </div>
        </div>
      </div>

      {/* Pricing & status */}
      <div className="adminCard">
        <div className="adminCardHeader"><h2>Pricing & status</h2></div>
        <div className="adminFormGrid two">
          <div className="adminField">
            <label htmlFor="p-category">Category *</label>
            <select id="p-category" className={errorFor('categoryId') ? 'hasError' : ''} value={categoryId} onChange={(e) => setCategoryId(e.target.value)} required>
              <option value="">Select a category…</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>{category.name}{category.isActive ? '' : ' (disabled)'}</option>
              ))}
            </select>
            {errorFor('categoryId') && <span className="adminFieldError">{errorFor('categoryId')}</span>}
          </div>
          <div className="adminField">
            <label htmlFor="p-status">Status *</label>
            <select id="p-status" className={errorFor('status') ? 'hasError' : ''} value={status} onChange={(e) => setStatus(e.target.value as ProductFormInitial['status'])}>
              <option value="DRAFT">Draft</option>
              <option value="ACTIVE">Active</option>
              <option value="ARCHIVED">Archived</option>
            </select>
            {errorFor('status') && <span className="adminFieldError">{errorFor('status')}</span>}
          </div>
          <div className="adminField">
            <label htmlFor="p-baseprice">Base price (₪) *</label>
            <input id="p-baseprice" className={errorFor('basePrice') ? 'hasError' : ''} type="number" min="0" step="0.01" value={basePrice} onChange={(e) => setBasePrice(e.target.value)} required />
            {errorFor('basePrice') && <span className="adminFieldError">{errorFor('basePrice')}</span>}
          </div>
          <div className="adminField">
            <label htmlFor="p-compareprice">Compare-at price (₪)</label>
            <input id="p-compareprice" className={errorFor('compareAtPrice') ? 'hasError' : ''} type="number" min="0" step="0.01" value={compareAtPrice} onChange={(e) => setCompareAtPrice(e.target.value)} />
            {errorFor('compareAtPrice') && <span className="adminFieldError">{errorFor('compareAtPrice')}</span>}
          </div>
        </div>
        <div className="adminCheckRow" style={{ marginTop: 13 }}>
          <label className={`adminCheck${isFeatured ? ' isOn' : ''}`}><input type="checkbox" checked={isFeatured} onChange={(e) => setIsFeatured(e.target.checked)} /> Featured</label>
          <label className={`adminCheck${isNewArrival ? ' isOn' : ''}`}><input type="checkbox" checked={isNewArrival} onChange={(e) => setIsNewArrival(e.target.checked)} /> New arrival</label>
          <label className={`adminCheck${isBestSeller ? ' isOn' : ''}`}><input type="checkbox" checked={isBestSeller} onChange={(e) => setIsBestSeller(e.target.checked)} /> Best seller</label>
        </div>
      </div>

      {/* Images */}
      <div className="adminCard">
        <div className="adminCardHeader">
          <div><h2>Images</h2><p className="adminMuted">Add image URLs or paths. The primary image is shown first.</p></div>
          <button type="button" className="adminBtn adminBtnGhost adminBtnSm" onClick={() => setImages((prev) => [...prev, { url: '', alt: '', isPrimary: prev.length === 0 }])}>+ Add image</button>
        </div>
        {errorFor('images') && <div className="adminAlert isError" style={{ marginBottom: 10 }}>{errorFor('images')}</div>}
        {images.length === 0 ? (
          <div className="adminEmptyState">No images yet. The storefront will use a fallback image.</div>
        ) : (
          images.map((image, index) => (
            <div className="adminRepeatRow" key={index}>
              <div className="adminRepeatHeader">
                <strong>Image {index + 1}</strong>
                <button type="button" className="adminBtn adminBtnDanger adminBtnSm" onClick={() => setImages((prev) => prev.filter((_, i) => i !== index))}>Remove</button>
              </div>
              <div className="adminRepeatGrid">
                <div className="adminField">
                  <label>Image URL or path *</label>
                  <input className={errorFor(`images.${index}.url`) ? 'hasError' : ''} value={image.url} onChange={(e) => updateImage(index, { url: e.target.value })} placeholder="/mock-products/bag-camel.svg" />
                  {errorFor(`images.${index}.url`) && <span className="adminFieldError">{errorFor(`images.${index}.url`)}</span>}
                </div>
                <div className="adminField">
                  <label>Alt text</label>
                  <input value={image.alt} onChange={(e) => updateImage(index, { alt: e.target.value })} />
                </div>
              </div>
              <label className={`adminCheck${image.isPrimary ? ' isOn' : ''}`} style={{ width: 'fit-content' }}>
                <input type="radio" name="primaryImage" checked={image.isPrimary} onChange={() => setPrimaryImage(index)} /> Primary image
              </label>
            </div>
          ))
        )}
      </div>

      {/* Variants */}
      <div className="adminCard">
        <div className="adminCardHeader">
          <div><h2>Variants</h2><p className="adminMuted">{activeVariantCount} active · {variants.length} total. SKUs must be unique.</p></div>
          <button type="button" className="adminBtn adminBtnGhost adminBtnSm" onClick={() => setVariants((prev) => [...prev, { ...EMPTY_VARIANT }])}>+ Add variant</button>
        </div>
        {variants.map((variant, index) => (
          <div className="adminRepeatRow" key={index}>
            <div className="adminRepeatHeader">
              <strong>Variant {index + 1}{variant.sku ? ` · ${variant.sku}` : ''}</strong>
              {variants.length > 1 && (
                <button type="button" className="adminBtn adminBtnDanger adminBtnSm" onClick={() => setVariants((prev) => prev.filter((_, i) => i !== index))}>Remove</button>
              )}
            </div>
            <div className="adminRepeatGrid">
              <div className="adminField">
                <label>SKU *</label>
                <input className={errorFor(`variants.${index}.sku`) ? 'hasError' : ''} value={variant.sku} onChange={(e) => updateVariant(index, { sku: e.target.value })} />
                {errorFor(`variants.${index}.sku`) && <span className="adminFieldError">{errorFor(`variants.${index}.sku`)}</span>}
              </div>
              <div className="adminField">
                <label>Size</label>
                <input value={variant.size} onChange={(e) => updateVariant(index, { size: e.target.value })} />
              </div>
              <div className="adminField">
                <label>Color name</label>
                <input value={variant.colorName} onChange={(e) => updateVariant(index, { colorName: e.target.value })} />
              </div>
              <div className="adminField">
                <label>Color value (hex)</label>
                <input value={variant.colorValue} onChange={(e) => updateVariant(index, { colorValue: e.target.value })} placeholder="#bd8754" />
              </div>
              <div className="adminField">
                <label>Price (₪) *</label>
                <input className={errorFor(`variants.${index}.price`) ? 'hasError' : ''} type="number" min="0" step="0.01" value={variant.price} onChange={(e) => updateVariant(index, { price: e.target.value })} />
                {errorFor(`variants.${index}.price`) && <span className="adminFieldError">{errorFor(`variants.${index}.price`)}</span>}
              </div>
              <div className="adminField">
                <label>Compare-at (₪)</label>
                <input type="number" min="0" step="0.01" value={variant.compareAtPrice} onChange={(e) => updateVariant(index, { compareAtPrice: e.target.value })} />
              </div>
              <div className="adminField">
                <label>Quantity *</label>
                <input className={errorFor(`variants.${index}.quantity`) ? 'hasError' : ''} type="number" min="0" step="1" value={variant.quantity} onChange={(e) => updateVariant(index, { quantity: e.target.value })} />
                {errorFor(`variants.${index}.quantity`) && <span className="adminFieldError">{errorFor(`variants.${index}.quantity`)}</span>}
              </div>
              <div className="adminField">
                <label>Low-stock threshold</label>
                <input type="number" min="0" step="1" value={variant.lowStockThreshold} onChange={(e) => updateVariant(index, { lowStockThreshold: e.target.value })} />
              </div>
            </div>
            <label className={`adminCheck${variant.isActive ? ' isOn' : ''}`} style={{ width: 'fit-content' }}>
              <input type="checkbox" checked={variant.isActive} onChange={(e) => updateVariant(index, { isActive: e.target.checked })} /> Active variant
            </label>
          </div>
        ))}
      </div>

      <div className="adminBtnRow">
        <button type="submit" className="adminBtn adminBtnPrimary" disabled={pending}>
          {pending ? 'Saving…' : mode === 'create' ? 'Create product' : 'Save changes'}
        </button>
        <button type="button" className="adminBtn adminBtnGhost" disabled={pending} onClick={() => router.push('/admin/products')}>Cancel</button>
      </div>
    </form>
  );
}
